# 智能文档处理应用 - 部署使用说明

## 环境要求

### 基础环境
- Python 3.8 或更高版本
- 4GB 以上内存（处理大文档建议8GB+）
- 足够的磁盘空间存储输入输出文件

### Python依赖
安装所需依赖：
```bash
pip install -r requirements.txt
```

核心依赖包：
- `spacy` 或 `nltk` - 自然语言处理
- `pyyaml` - 配置文件管理
- `tqdm` - 进度显示
- `python-Levenshtein` - 文本相似度计算

## 快速开始

### 1. 准备输入文档
将需要处理的Markdown文档放入 `docs/input/` 目录：
```bash
mkdir -p docs/input
cp your_documents/*.md docs/input/
```

### 2. 单文件处理
使用自然语言指令处理单个文档集：
```
请执行多文档无损合并，然后智能去重，最后生成深度总结报告
```

### 3. 批量处理
处理整个目录的文档：
```bash
python scripts/batch_process.py --input-dir ./batch_input --output-dir ./batch_output
```

## 输入数据制备

### 文档格式要求
- 文件格式：Markdown (.md)
- 编码：UTF-8
- 最大文件大小：建议不超过10MB

### 文件命名规范
建议使用有意义的文件名：
- `topic_chapter1.md`
- `project_documentation.md`
- `research_paper_part1.md`

### 目录结构示例
```
docs/input/
├── technical_specs.md
├── user_guide.md
├── api_documentation.md
└── release_notes.md
```

## 使用自然语言指令操作

### 基本操作指令
```
请帮我合并这些技术文档并生成总结报告
```

```
对这些Markdown文件进行智能去重，相似度阈值设为90%
```

```
分析这个文档集合的主要主题和关键观点
```

### 高级操作指令
```
使用主题合并策略，按内容相关性组织文档结构
```

```
启用分块处理模式，处理大型文档集合
```

```
调整去重算法参数，提高精确度但降低召回率
```

## 配置自定义

### 修改处理规则
编辑 `config/rules.yaml`：
```yaml
deduplication:
  similarity_threshold: 0.85
  preserve_order: latest
  
merging:
  strategy: sequential
  add_separators: true
  
analysis:
  depth: deep
  include_statistics: true
```

### 性能调优
在 `config/settings.yaml` 中调整：
```yaml
performance:
  chunk_size: 1000000
  max_workers: 4
  cache_models: true
```

## 输出结果

### 生成文件
- `output/merged_document.md` - 合并后的完整文档
- `output/deduplicated_document.md` - 去重后的文档
- `output/analysis_report.md` - 深度分析报告

### 报告内容
分析报告包含：
- 文档结构分析
- 主要主题提取
- 关键观点总结
- 重复内容统计
- 处理质量评估

## 故障排除

### 常见问题
1. **内存不足**：减小 `chunk_size` 或启用分块处理
2. **处理速度慢**：减少 `max_workers` 或使用更轻量级NLP模型
3. **去重效果不佳**：调整 `similarity_threshold`

### 获取帮助
查看详细日志：
```bash
tail -f logs/processing.log
```

## 高级功能

### 自定义分析模板
在 `docs/templates/` 中创建自定义报告模板

### 扩展处理管道
通过修改 `src/main.py` 添加新的处理步骤

### 集成其他工具
支持与其他文档处理工具链集成